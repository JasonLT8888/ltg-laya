package ltgame.ads;

import android.util.Log;

import com.heytap.msp.mobad.api.ad.NativeAd;
import com.heytap.msp.mobad.api.listener.INativeAdListener;
import com.heytap.msp.mobad.api.params.INativeAdData;
import com.heytap.msp.mobad.api.params.INativeAdFile;
import com.heytap.msp.mobad.api.params.NativeAdError;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import layaair.game.Market.GameEngine;
import ltgame.ADConst;
import ltgame.LTADManager;

public class OPNativeAD implements INativeAdListener {

    private static String TAG = "OPNativeAD";

    private NativeAd _nativeAd;
    private INativeAdData _nativeAdData;

    public void LoadNativeAD() {
        if(_nativeAd == null) {
            _nativeAd = new NativeAd(LTADManager.getInstance().context,
                    ADConst.nativeAdId, this);
        }
        _nativeAdData = null;
        _nativeAd.loadAd();
    }

    public void ReportClick() {
        if(_nativeAdData == null) return;
        _nativeAdData.onAdClick(GameEngine.getInstance().game_plugin_get_view());
    }

    public void ReportShow() {
        if(_nativeAdData == null) return;
        _nativeAdData.onAdShow(GameEngine.getInstance().game_plugin_get_view());
    }

    @Override
    public void onAdSuccess(List<INativeAdData> list) {
        Log.d(TAG, "onAdSuccess count:" + list.size());
        if (null != list && list.size() > 0) {
            _nativeAdData = (INativeAdData) list.get(0);

            String imgUrl = "";
            List<INativeAdFile> imgFiles = _nativeAdData.getImgFiles();
            if (imgFiles != null && imgFiles.size() > 0) {
                INativeAdFile adFile = imgFiles.get(0);
                imgUrl = adFile.getUrl();
                Log.d(TAG, "adFile_img" + imgUrl);
            }

            String logoUrl = null != _nativeAdData.getLogoFile() ? _nativeAdData.getLogoFile().getUrl() : "";
            String title = null != _nativeAdData.getTitle() ? _nativeAdData.getTitle() : "";
            String desc = null != _nativeAdData.getDesc() ? _nativeAdData.getDesc() : "";

            Map<String, String> map = new HashMap<String, String>();
            map.put("imgUrl", imgUrl);
            map.put("logoUrl", logoUrl);
            map.put("title", title);
            map.put("desc", desc);
            JSONObject jsonObj = new JSONObject(map);
            String transJson = jsonObj.toString();
            Log.d(TAG, "回传json:" + transJson);
            LTADManager.getInstance().SendJsonToLaya("NativeAdData", transJson);
        }
    }

    @Override
    public void onAdFailed(NativeAdError nativeAdError) {
        Log.e(TAG, "加载原生广告失败,错误码:" + nativeAdError.toString());
        LTADManager.getInstance().SendMsgToLaya("NativeAdFailed", nativeAdError.toString());
    }

    @Override
    public void onAdError(NativeAdError nativeAdError, INativeAdData iNativeAdData) {
        Log.e(TAG, "调用原生广告统计方法出错,错误码：" + nativeAdError.toString());
    }

}
