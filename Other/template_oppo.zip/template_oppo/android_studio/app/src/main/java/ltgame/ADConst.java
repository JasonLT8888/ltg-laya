package ltgame;

public class ADConst {

    public static String appId = "30495213";
    public static String bannerId = "301032";
    public static String interstitialId = "301033";
    public static String splashId = "301035";
    public static String rewardVideoId = "301046";
    public static String nativeAdId = "301039";

}
