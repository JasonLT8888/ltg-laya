package ltgame.ads;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.nfc.Tag;
import android.util.Log;

import com.heytap.msp.mobad.api.ad.RewardVideoAd;
import com.heytap.msp.mobad.api.listener.IRewardVideoAdListener;
import com.heytap.msp.mobad.api.params.RewardVideoAdParams;

import ltgame.ADConst;
import ltgame.LTADManager;

public class OPRewardVideoAD implements IRewardVideoAdListener {

    private static String TAG = "OPRewardVideoAD";

    private RewardVideoAd _rewardAd;

    private String mRewardTips;

    /**
     * add 2018-10-25
     * 激励视频广告前置引导提示，主要用于提示用户如何操作才能获取奖励。
     * 目前支持三种种激励场景：
     * 1、视频播放完成；
     * 2、点击下载安装完成获取激励；
     * 3、点击下载安装后打开获取激励。
     * 应用在接入的时候，需要根据自己应用场景，对用户进行一定的引导。
     */
    private static final String REWARD_SCENE_PLAY_COMPLETE_TIPS = "视频播放完成才可以获得奖励哦";
    private static final String REWARD_SCENE_INSTALL_COMPLETE_TIPS = "应用安装完成才可以获得奖励哦";
    private static final String REWARD_SCENE_LAUNCH_APP_TIPS = "应用安装完成点击打开才可以获得奖励哦";

    public void Show() {
        if(this._rewardAd != null) {
            if(this._rewardAd.isReady()) {
                this._ShowNotice();
            } else {
                this._rewardAd.destroyAd();
                this._rewardAd = null;
            }
            return;
        }
        this._rewardAd = new RewardVideoAd(LTADManager.getInstance().context,
                ADConst.rewardVideoId, this);
        /**
         * 调用loadAd方法请求激励视频广告;通过RewardVideoAdParams.setFetchTimeout方法可以设置请求
         * 视频广告最大超时时间，单位毫秒；
         */
        RewardVideoAdParams rewardVideoAdParams = new RewardVideoAdParams.Builder()
                .setFetchTimeout(3000)
                .build();
        this._rewardAd.loadAd(rewardVideoAdParams);
    }

    private void _ShowNotice() {
        /**
         * 请求视频广告成功、展示播放视频的入口Dialog、
         * 根据getRewardScene方法返回的激励场景、提示引导用户如何操作才能获取奖励。
         * 这里只是Demo效果、应用可以结合自己的游戏场景来引导。
         */
        switch (_rewardAd.getRewardScene()) {
            case RewardVideoAd.REWARD_SCENE_PLAY_COMPLETE:
                mRewardTips = REWARD_SCENE_PLAY_COMPLETE_TIPS;
                break;
            case RewardVideoAd.REWARD_SCENE_INSTALL_COMPLETE:
                mRewardTips = REWARD_SCENE_INSTALL_COMPLETE_TIPS;
                break;
            case RewardVideoAd.REWARD_SCENE_LAUNCH_APP:
                mRewardTips = REWARD_SCENE_LAUNCH_APP_TIPS;
                break;
        }

        AlertDialog alertDialog = new AlertDialog.Builder(LTADManager.getInstance().context)
                .setCancelable(false)
                .setTitle("获取奖励提示")
                .setMessage(mRewardTips)
                .setPositiveButton("播放", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        playVideo();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        LTADManager.getInstance().SendMsgToLaya("RewardVideo","failed");
                    }
                })
                .create();
        alertDialog.show();
    }

    @Override
    public void onAdSuccess() {
        this._ShowNotice();
    }

    private void playVideo() {
        /**
         * 在播放广告时候，先调用isReady方法判断当前是否有广告可以播放；如果有、再调用showAd方法播放激励视频广告。
         */
        if (_rewardAd.isReady()) {
            _rewardAd.showAd();
        } else {
            Log.e(TAG, "广告尚未加载成功");
            LTADManager.getInstance().SendMsgToLaya("RewardVideo","failed");
        }
    }

    @Override
    public void onAdFailed(String s) {
        Log.e(TAG, "onAdFailed:" + s);
        LTADManager.getInstance().SendMsgToLaya("RewardVideo","failed");
    }

    @Override
    public void onAdFailed(int i, String s) {
        Log.e(TAG, "onAdFailed:" + s + "count:" + i);
        LTADManager.getInstance().SendMsgToLaya("RewardVideo","failed");
    }

    @Override
    public void onAdClick(long l) {
        Log.i(TAG, "onAdClick:" + l);
    }

    @Override
    public void onVideoPlayStart() {
        Log.i(TAG, "onVideoPlayStart");
    }

    @Override
    public void onVideoPlayComplete() {
        Log.i(TAG, "onVideoPlayComplete");
    }

    @Override
    public void onVideoPlayError(String s) {
        Log.e(TAG, "onVideoPlayError");
        LTADManager.getInstance().SendMsgToLaya("RewardVideo","failed");
    }

    @Override
    public void onVideoPlayClose(long l) {
        Log.i(TAG, "onVideoPlayClose:" + l);
        LTADManager.getInstance().SendMsgToLaya("RewardVideo","skipped");
        this._SendClose();
    }

    @Override
    public void onLandingPageOpen() {
        Log.i(TAG, "onLandingPageOpen");
    }

    @Override
    public void onLandingPageClose() {
        Log.i(TAG, "onLandingPageClose");
        this._SendClose();
    }

    private void _SendClose() {
        LTADManager.getInstance().SendMsgToLaya("RewardVideo","closed");
        this._rewardAd.destroyAd();
        this._rewardAd = null;
    }

    @Override
    public void onReward(Object... objects) {
        Log.i(TAG, "onReward");
        LTADManager.getInstance().SendMsgToLaya("RewardVideo","rewarded");
    }

}
