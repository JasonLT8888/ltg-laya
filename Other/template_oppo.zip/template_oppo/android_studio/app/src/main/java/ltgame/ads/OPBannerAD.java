package ltgame.ads;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.heytap.msp.mobad.api.ad.BannerAd;
import com.heytap.msp.mobad.api.listener.IBannerAdListener;

import ltgame.ADConst;
import ltgame.LTADManager;

public class OPBannerAD implements IBannerAdListener {

    private static String TAG = "OPBannerAD";

    private BannerAd _bannerAd;

    public void Show() {
        if(this._bannerAd == null) {
            this._bannerAd = new BannerAd(LTADManager.getInstance().context, ADConst.bannerId);
            this._bannerAd.setAdListener(this);
            View adView = this._bannerAd.getAdView();
            /**
             * mBannerAd.getAdView()返回可能为空，判断后在添加
             */
            if (null != adView) {
                /**
                 * 这里addView是可以自己指定Banner广告的放置位置【一般是页面顶部或者底部】
                 */
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                LTADManager.getInstance().adContainer.addView(adView, layoutParams);
                this._bannerAd.loadAd();
            } else {
                Log.e(TAG, "无法创建banner");
                this.Hide();
            }
        }
    }

    public void Hide() {
        if(this._bannerAd == null) {
            return;
        }
        this._bannerAd.destroyAd();
        this._bannerAd = null;
    }

    @Override
    public void onAdReady() {
        Log.d(TAG, "onAdReady");
    }

    @Override
    public void onAdClose() {
        Log.d(TAG, "onAdClose");
    }

    @Override
    public void onAdShow() {
        Log.d(TAG, "onAdShow");
    }

    @Override
    public void onAdFailed(String s) {
        Log.d(TAG, "onAdFailed:" + s);
    }

    @Override
    public void onAdFailed(int i, String s) {
        Log.d(TAG, "onAdFailed:" + s + " count:" + i);
    }

    @Override
    public void onAdClick() {
        Log.d(TAG, "onAdClick");
    }
}
