package ltgame;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.heytap.msp.mobad.api.InitParams;
import com.heytap.msp.mobad.api.MobAdManager;
import com.heytap.msp.mobad.api.listener.IInitListener;

import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import demo.JSBridge;
import layaair.game.browser.ExportJavaFunction;
import ltgame.ads.OPBannerAD;
import ltgame.ads.OPInterstitialAD;
import ltgame.ads.OPNativeAD;
import ltgame.ads.OPRewardVideoAD;

public class LTADManager {

    private static String TAG = "LTADManager";

    private static LTADManager _instance;
    public static LTADManager getInstance() {
        if(LTADManager._instance == null) {
            LTADManager._instance = new LTADManager();
        }
        return LTADManager._instance;
    }

    public Activity context;

    private boolean _isInited = false;
    public RelativeLayout adContainer;

    private OPBannerAD _bannerAd;
    private OPRewardVideoAD _rewardVideo;
    private OPInterstitialAD _interstitalAd;
    private OPNativeAD _nativeAd;

    private LTADManager() {

    }

    public void Init() {
        if(this._isInited) return;
        this._InitAd();
        this._CloseAndroidPDialog();
    }

    public void SetAdContainer(RelativeLayout adContainer) {
        this.adContainer = adContainer;
        this._bannerAd = new OPBannerAD();
        this._rewardVideo = new OPRewardVideoAD();
        this._interstitalAd = new OPInterstitialAD();
        this._nativeAd = new OPNativeAD();
    }

    public void HandleLayaEvent(String eventStr) {
        Log.i(TAG, "接收到LayaEvent:" + eventStr);
        switch (eventStr) {
            case "ShowBannerAd":
                this._bannerAd.Show();
                break;
            case "HideBannerAd":
                this._bannerAd.Hide();
                break;
            case "ShowRewardVideoAd":
                this._rewardVideo.Show();
                break;
            case "ShowInterstitalAd":
                this._interstitalAd.Show();
                break;
            case "LoadNativeAD":
                this._nativeAd.LoadNativeAD();
                break;
            case "NativeADShow":
                this._nativeAd.ReportShow();
                break;
            case "NativeADClick":
                this._nativeAd.ReportClick();
                break;
            default:
                Log.e(TAG, "未处理的LayaEvent:" + eventStr);
                break;
        }
    }

    public void SendMsgToLaya(String type, String msg) {
        String combieStr = "{\"type\":\"" + type + "\",\"msg\":\"" + msg + "\"}";
        ExportJavaFunction.CallBackToJS(JSBridge.class,"_AsyncBack", combieStr);
    }

    public void SendJsonToLaya(String type, String json) {
        String combieStr = "{\"type\":\"" + type + "\",\"msg\":" + json + "}";
        ExportJavaFunction.CallBackToJS(JSBridge.class,"_AsyncBack", combieStr);
    }

    /**
     * 解决Android9.0以上出现Detected problems with API compatibility的弹框
     */
    private void _CloseAndroidPDialog() {
        try {
            Class<?> cls = Class.forName("android.app.ActivityThread");
            Method declaredMethod = cls.getDeclaredMethod("currentActivityThread");
            declaredMethod.setAccessible(true);
            Object activityThread = declaredMethod.invoke(null);
            Field mHiddenApiWarningShown = cls.getDeclaredField("mHiddenApiWarningShown");
            mHiddenApiWarningShown.setAccessible(true);
            mHiddenApiWarningShown.setBoolean(activityThread, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void _InitAd() {
        InitParams initParams = new InitParams.Builder()
                .setDebug(true)//true打开SDK日志，当应用发布Release版本时，必须注释掉这行代码的调用，或者设为false
                .build();
        /**
         * 调用这行代码初始化广告SDK
         */
        MobAdManager.getInstance().init(this.context, ADConst.appId, initParams, new IInitListener() {
            @Override
            public void onSuccess() {
                Log.d("MobAdDemoApp", "IInitListener onSuccess");
                _isInited = true;
            }

            @Override
            public void onFailed(String s) {
                Log.d("MobAdDemoApp", "IInitListener onFailed");
            }
        });
    }

}
