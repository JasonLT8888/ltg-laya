package ltgame.ads;

import android.util.Log;

import com.heytap.msp.mobad.api.ad.InterstitialAd;
import com.heytap.msp.mobad.api.listener.IInterstitialAdListener;

import ltgame.ADConst;
import ltgame.LTADManager;

public class OPInterstitialAD implements IInterstitialAdListener {

    private static String TAG = "OPInterstitialAD";

    private InterstitialAd _interstitalAd;

    public void Show() {
        if(_interstitalAd == null) {
            _interstitalAd = new InterstitialAd(LTADManager.getInstance().context,
                    ADConst.interstitialId);
            _interstitalAd.setAdListener(this);
        }
        _interstitalAd.loadAd();
    }

    @Override
    public void onAdReady() {
        Log.d(TAG, "onAdReady");
        _interstitalAd.showAd();
        LTADManager.getInstance().SendMsgToLaya("InterstitalAD", "ready");
    }

    @Override
    public void onAdClose() {
        Log.d(TAG, "onAdClose");
    }

    @Override
    public void onAdShow() {
        Log.d(TAG, "onAdShow");
    }

    @Override
    public void onAdFailed(String s) {
        Log.e(TAG, "onAdFailed:" + s);
        if(_interstitalAd != null) {
            _interstitalAd.destroyAd();
            _interstitalAd = null;
        }
    }

    @Override
    public void onAdFailed(int i, String s) {
        Log.e(TAG, "onAdFailed:" + s + "count:" + i);
        if(_interstitalAd != null) {
            _interstitalAd.destroyAd();
            _interstitalAd = null;
        }
    }

    @Override
    public void onAdClick() {
        Log.d(TAG, "onAdClick");
    }

}
